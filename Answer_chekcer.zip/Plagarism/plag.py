# from flask import Flask, request, jsonify
# from difflib import SequenceMatcher
# import PyPDF2
# import os
# import tempfile

# app = Flask(__name__)

# # Function to read the text from a file
# def read_file_content(file_path):
#     text = ""
#     if file_path.endswith('.txt'):
#         with open(file_path, 'r', encoding='utf-8') as file:
#             text = file.read()
#     elif file_path.endswith('.pdf'):
#         with open(file_path, 'rb') as file:
#             reader = PyPDF2.PdfReader(file)
#             text = ''.join([page.extract_text() for page in reader.pages])
#     else:
#         raise ValueError("Unsupported file type. Only .txt and .pdf are allowed.")
#     return text

# # Function to calculate plagiarism percentage
# def calculate_similarity(text1, text2):
#     return SequenceMatcher(None, text1, text2).ratio() * 100

# # API route to check plagiarism
# @app.route('/check-plagiarism', methods=['POST'])
# def check_plagiarism():
#     # Check if the source file exists
#     source_file = 'solution.txt'
#     if not os.path.exists(source_file):
#         return jsonify({"error": "Source file 'solution.txt' not found."}), 400

#     try:
#         # Read the source file content
#         source_text = read_file_content(source_file)

#         # Check if a file is uploaded
#         if 'file' not in request.files:
#             return jsonify({"error": "No file uploaded."}), 400

#         uploaded_file = request.files['file']
#         uploaded_file_path = tempfile.mktemp(suffix=f"_{uploaded_file.filename.replace(' ', '_')}")

#         # uploaded_file_path = f"/tmp/{uploaded_file.filename}"

#         # Save the uploaded file temporarily
#         uploaded_file.save(uploaded_file_path)

#         # Read the uploaded file content
#         uploaded_text = read_file_content(uploaded_file_path)

#         # Calculate plagiarism percentage
#         similarity = calculate_similarity(uploaded_text, source_text)

#         # Clean up the temporary file
#         os.remove(uploaded_file_path)

#         return jsonify({
#             "plagiarism_percentage": similarity
#         })

#     except ValueError as ve:
#         return jsonify({"error": str(ve)}), 400
#     except Exception as e:
#         return jsonify({"error": "An unexpected error occurred.", "details": str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True)







from flask import Flask, request, jsonify
from flask_cors import CORS
from difflib import SequenceMatcher
import PyPDF2
import os
import tempfile

app = Flask(__name__)
CORS(app)  # This will allow all origins by default

# Function to read the text from a file
def read_file_content(file_path):
    text = ""
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
    elif file_path.endswith('.pdf'):
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ''.join([page.extract_text() for page in reader.pages])
    else:
        raise ValueError("Unsupported file type. Only .txt and .pdf are allowed.")
    return text

# Function to calculate plagiarism percentage
def calculate_similarity(text1, text2):
    return SequenceMatcher(None, text1, text2).ratio() * 100

# API route to check plagiarism
@app.route('/check-plagiarism', methods=['POST'])
def check_plagiarism():
    source_file = 'solution.txt'
    if not os.path.exists(source_file):
        return jsonify({"error": "Source file 'solution.txt' not found."}), 400

    try:
        source_text = read_file_content(source_file)

        if 'file' not in request.files:
            return jsonify({"error": "No file uploaded."}), 400

        uploaded_file = request.files['file']
        uploaded_file_path = tempfile.mktemp(suffix=f"_{uploaded_file.filename.replace(' ', '_')}")
        uploaded_file.save(uploaded_file_path)

        uploaded_text = read_file_content(uploaded_file_path)

        similarity = calculate_similarity(uploaded_text, source_text)

        os.remove(uploaded_file_path)

        return jsonify({
            "plagiarism_percentage": similarity
        })

    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred.", "details": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
