document.getElementById("post-button").addEventListener("click", function() {
    console.log("Post button clicked");

    // Get the value from the textarea
    const announcementText = document.getElementById("announcement-text").value;
    console.log("Announcement Text:", announcementText);

    // Check if the textarea is empty
    if (announcementText.trim() === "") {
        alert("Please write something before posting.");
        return;
    }

    // Create a new post element
    const newPost = document.createElement("div");
    newPost.classList.add("post");

    // Create post header
    const postHeader = document.createElement("div");
    postHeader.classList.add("post-header");

    const teacherName = document.createElement("span");
    teacherName.classList.add("teacher-name");
    teacherName.textContent = "You"; // Replace "You" with a dynamic user name if needed
    postHeader.appendChild(teacherName);

    const postDate = document.createElement("span");
    postDate.classList.add("post-date");
    const currentDate = new Date();
    postDate.textContent = currentDate.toLocaleDateString();
    postHeader.appendChild(postDate);

    newPost.appendChild(postHeader);

    // Add the announcement text content to the post
    const postContent = document.createElement("p");
    postContent.textContent = announcementText;
    newPost.appendChild(postContent);

    // Append the new post to the content area
    const contentArea = document.querySelector(".content-area");
    if (contentArea) {
        contentArea.prepend(newPost);
        console.log("New post added:", newPost);
    } else {
        console.error("Content area not found.");
    }

    // Clear the textarea after posting
    document.getElementById("announcement-text").value = "";
});
